# ResearchSynth
A document summariser specific for Abstract Generation for Scientific Papers.
